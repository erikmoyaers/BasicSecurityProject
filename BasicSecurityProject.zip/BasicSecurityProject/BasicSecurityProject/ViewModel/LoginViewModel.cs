﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BasicSecurityProject.ViewModel
{
    public class LoginViewModel
    {
        public String Username { get; set; }
        public String Password { get; set; }
    }
}
